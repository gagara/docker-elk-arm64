'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ui_render_mixin = require('./ui_render_mixin');

Object.defineProperty(exports, 'uiRenderMixin', {
  enumerable: true,
  get: function () {
    return _ui_render_mixin.uiRenderMixin;
  }
});