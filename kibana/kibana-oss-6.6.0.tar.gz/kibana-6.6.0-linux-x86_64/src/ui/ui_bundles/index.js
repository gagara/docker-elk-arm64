'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ui_bundles_mixin = require('./ui_bundles_mixin');

Object.defineProperty(exports, 'uiBundlesMixin', {
  enumerable: true,
  get: function () {
    return _ui_bundles_mixin.uiBundlesMixin;
  }
});