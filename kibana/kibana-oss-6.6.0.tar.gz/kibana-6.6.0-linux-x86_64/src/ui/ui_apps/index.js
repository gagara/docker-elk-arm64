'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _ui_apps_mixin = require('./ui_apps_mixin');

Object.defineProperty(exports, 'uiAppsMixin', {
  enumerable: true,
  get: function () {
    return _ui_apps_mixin.uiAppsMixin;
  }
});