'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _sample_data_mixin = require('./sample_data_mixin');

Object.defineProperty(exports, 'sampleDataMixin', {
  enumerable: true,
  get: function () {
    return _sample_data_mixin.sampleDataMixin;
  }
});