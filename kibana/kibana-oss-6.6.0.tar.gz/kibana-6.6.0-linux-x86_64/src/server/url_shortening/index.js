'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _url_shortening_mixin = require('./url_shortening_mixin');

Object.defineProperty(exports, 'urlShorteningMixin', {
  enumerable: true,
  get: function () {
    return _url_shortening_mixin.urlShorteningMixin;
  }
});