'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _server_extensions_mixin = require('./server_extensions_mixin');

Object.defineProperty(exports, 'serverExtensionsMixin', {
  enumerable: true,
  get: function () {
    return _server_extensions_mixin.serverExtensionsMixin;
  }
});