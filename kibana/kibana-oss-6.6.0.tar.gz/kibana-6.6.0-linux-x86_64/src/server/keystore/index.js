'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keystore = require('./keystore');

Object.defineProperty(exports, 'Keystore', {
  enumerable: true,
  get: function () {
    return _keystore.Keystore;
  }
});