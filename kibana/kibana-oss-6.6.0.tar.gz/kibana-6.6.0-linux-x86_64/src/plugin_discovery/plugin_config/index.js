'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extend_config_service = require('./extend_config_service');

Object.defineProperty(exports, 'extendConfigService', {
  enumerable: true,
  get: function () {
    return _extend_config_service.extendConfigService;
  }
});
Object.defineProperty(exports, 'disableConfigExtension', {
  enumerable: true,
  get: function () {
    return _extend_config_service.disableConfigExtension;
  }
});