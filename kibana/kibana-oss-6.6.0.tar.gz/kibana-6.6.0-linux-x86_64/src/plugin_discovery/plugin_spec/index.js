'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _plugin_spec = require('./plugin_spec');

Object.defineProperty(exports, 'PluginSpec', {
  enumerable: true,
  get: function () {
    return _plugin_spec.PluginSpec;
  }
});