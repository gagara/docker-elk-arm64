'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _reduce_export_specs = require('./reduce_export_specs');

Object.defineProperty(exports, 'reduceExportSpecs', {
  enumerable: true,
  get: function () {
    return _reduce_export_specs.reduceExportSpecs;
  }
});